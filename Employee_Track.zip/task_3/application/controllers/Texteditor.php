<?php

class Texteditor extends CI_Controller
{

    public function index()
    {
        $this->load->view('text_editor_view');
    }
}
